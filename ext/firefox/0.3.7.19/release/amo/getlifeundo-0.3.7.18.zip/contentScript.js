(function(){
  const MAX = 20;

  function isPwd(el){
    if (!el) return false;
    if (el instanceof HTMLInputElement) {
      const t = (el.type||'').toLowerCase();
      if (t === 'password' || t === 'hidden') return true;
    }
    const s = ((el.name||'') + ' ' + (el.id||'') + ' ' + (el.className||'')).toLowerCase();
    return /pass|passwd|password/.test(s);
  }

  async function save(key, entry){
    try{
      const cur = (await browser.storage.local.get(key))[key] || [];
      const filtered = cur.filter(x => x.text !== entry.text);
      const next = [entry, ...filtered].slice(0, MAX);
      await browser.storage.local.set({ [key]: next });
    }catch(e){}
  }

  addEventListener('input', e=>{
    const el = e.target;
    if (!el) return;
    if (el.isContentEditable) {
      const v = (el.textContent||'').trim();
      if (v) save('lu_inputs', { text: v, ts: Date.now() });
      return;
    }
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      if (!isPwd(el)) {
        const v = (el.value||'').trim();
        if (v) save('lu_inputs', { text: v, ts: Date.now() });
      }
    }
  }, true);

  addEventListener('change', e=>{
    const el = e.target;
    if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      if (!isPwd(el)) {
        const v = (el.value||'').trim();
        if (v) save('lu_inputs', { text: v, ts: Date.now() });
      }
    }
  }, true);

  addEventListener('copy', ()=>{
    try{
      const sel = String(document.getSelection()||'').trim();
      if (sel) save('lu_clipboard', { text: sel, ts: Date.now() });
    }catch(e){}
  }, true);
})();