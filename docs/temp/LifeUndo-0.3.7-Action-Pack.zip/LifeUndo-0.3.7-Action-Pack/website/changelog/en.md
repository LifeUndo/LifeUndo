# LifeUndo 0.3.7 — 2025-09-18

### What's new
- “Activate VIP” button now opens the built‑in License page (offline ECDSA verification).
- RU/EN toggle fixed (incl. “What’s new” modal and footer labels).
- UI polish: stable popup size; correct VIP/PRO states.

### Compatibility
Firefox (AMO). Chrome/Edge — in progress.

