// LifeUndo License Verification Module
// Implements ECDSA P-256 signature verification for .lifelic files

import { LICENSE_PUB_KEY_JWK } from './licensePubKey.js';

/**
 * Canonical JSON stringify function that ensures consistent ordering
 * of object keys for deterministic hashing
 */
function canonicalJSONStringify(obj) {
  if (obj === null || typeof obj !== 'object') {
    return JSON.stringify(obj);
  }
  
  if (Array.isArray(obj)) {
    return '[' + obj.map(canonicalJSONStringify).join(',') + ']';
  }
  
  const keys = Object.keys(obj).sort();
  return '{' + keys.map(k => 
    JSON.stringify(k) + ':' + canonicalJSONStringify(obj[k])
  ).join(',') + '}';
}

const enc = new TextEncoder();

/**
 * Import public key from JWK format
 */
async function importPublicKey(jwk) {
  return crypto.subtle.importKey(
    'jwk',
    jwk,
    { name: 'ECDSA', namedCurve: 'P-256' },
    true,
    ['verify']
  );
}

/**
 * Verify license signature using ECDSA P-256 with SHA-256
 * @param {Object} obj - License object with {license, signature}
 * @returns {Promise<boolean>} - True if signature is valid
 */
export async function verifyLicenseSignature(obj) {
  const { license, signature } = obj;
  
  if (!license || !signature) {
    return false;
  }
  
  try {
    // Create canonical JSON string from license object
    const payload = enc.encode(canonicalJSONStringify(license));
    
    // Decode base64 signature
    const sigBytes = Uint8Array.from(atob(signature.sig_b64), c => c.charCodeAt(0));
    
    // Import public key (use provided key or fallback to default)
    const pubKey = await importPublicKey(signature.publicKeyJwk || LICENSE_PUB_KEY_JWK);
    
    // Verify signature
    return crypto.subtle.verify(
      { name: 'ECDSA', hash: 'SHA-256' },
      pubKey,
      sigBytes,
      payload
    );
  } catch (error) {
    console.error('License verification error:', error);
    return false;
  }
}

/**
 * Check if a license is valid and not expired
 * @param {Object} license - License object
 * @returns {boolean} - True if license is valid and not expired
 */
export function isLicenseValid(license) {
  if (!license || !license.plan) {
    return false;
  }
  
  // Check expiration date if present
  if (license.expiry) {
    const today = new Date().toISOString().slice(0, 10);
    return license.expiry >= today;
  }
  
  return true; // No expiration date means perpetual license
}

/**
 * Check if license is VIP tier
 * @param {Object} license - License object
 * @returns {boolean} - True if license is VIP tier
 */
export function isVipLicense(license) {
  return license && license.plan === 'vip';
}
