// LifeUndo Options Page
import { LINKS, TRIAL_DAYS } from './constants.js';
import { verifyLicenseSignature, isLicenseValid, isVipLicense } from './verifyLicense.js';

class OptionsManager {
  constructor() {
    this.init();
  }

  async init() {
    await this.loadData();
    await this.loadSavedLicense();
    this.setupEventListeners();
  }

  async loadData() {
    try {
      // Load statistics and pro status
      const response = await chrome.runtime.sendMessage({ type: 'LU_GET_STATS' });
      if (response.ok) {
        this.updateStats(response.stats);
        this.updateLicenseStatus(response.pro);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
  }

  updateStats(stats) {
    if (!stats) return;

    document.getElementById('popupOpens').textContent = stats.popupOpens || 0;
    document.getElementById('undos').textContent = stats.undos || 0;
    document.getElementById('tabRestores').textContent = stats.tabRestores || 0;
    document.getElementById('clipboardRestores').textContent = stats.clipboardRestores || 0;
  }

  async loadSavedLicense() {
    try {
      const { license, signature } = await chrome.storage.local.get(['license', 'signature']);
      if (license && signature) {
        const isValid = await verifyLicenseSignature({ license, signature });
        if (isValid && isLicenseValid(license)) {
          const plan = license.plan || 'unknown';
          const devices = license.devices || 'unknown';
          const expiry = license.expiry || 'perpetual';
          this.showStatus(`Найдена лицензия (plan: ${plan}, devices: ${devices}, expiry: ${expiry})`, 'success');
        } else {
          this.showStatus('Сохраненная лицензия недействительна', 'error');
        }
      } else {
        this.showStatus('Лицензия не установлена');
      }
    } catch (error) {
      console.error('Error loading saved license:', error);
      this.showStatus('Ошибка загрузки лицензии', 'error');
    }
  }

  updateLicenseStatus(pro) {
    if (!pro) return;

    const statusEl = document.getElementById('licenseStatus');
    const trialInfoEl = document.getElementById('trialInfo');
    const trialDaysEl = document.getElementById('trialDays');

    statusEl.classList.remove('hidden', 'success', 'error', 'info');

    if (pro.status === 'pro') {
      statusEl.textContent = '✅ Pro License Active';
      statusEl.classList.add('success');
      trialInfoEl.classList.add('hidden');
    } else if (pro.status === 'trial') {
      const trialStart = pro.trialStart || Date.now();
      const daysLeft = Math.max(0, TRIAL_DAYS - Math.floor((Date.now() - trialStart) / (24 * 60 * 60 * 1000)));
      
      if (daysLeft > 0) {
        statusEl.textContent = `🕒 Trial Active (${daysLeft} days left)`;
        statusEl.classList.add('info');
        trialDaysEl.textContent = daysLeft;
        trialInfoEl.classList.remove('hidden');
      } else {
        statusEl.textContent = '❌ Trial Expired - Upgrade to Pro';
        statusEl.classList.add('error');
        trialInfoEl.classList.add('hidden');
      }
    } else {
      statusEl.textContent = '🆓 Free Version';
      statusEl.classList.add('info');
      trialInfoEl.classList.add('hidden');
    }
  }

  setupEventListeners() {
    // License import functionality
    document.getElementById('importBtn').addEventListener('click', () => {
      this.importLicense();
    });

    document.getElementById('verifyBtn').addEventListener('click', () => {
      this.verifySavedLicense();
    });

    document.getElementById('clearBtn').addEventListener('click', () => {
      this.clearSavedLicense();
    });

    // License activation (legacy)
    document.getElementById('activateBtn').addEventListener('click', () => {
      this.activateLicense();
    });

    // Enter key for license input
    document.getElementById('licenseKey').addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        this.activateLicense();
      }
    });

    // Export data
    document.getElementById('exportBtn').addEventListener('click', () => {
      this.exportData();
    });

    // Reset statistics
    document.getElementById('resetBtn').addEventListener('click', () => {
      this.resetStats();
    });
  }

  async importLicense() {
    const fileInput = document.getElementById('licenseFile');
    const file = fileInput.files[0];
    
    if (!file) {
      this.showStatus('Выберите файл .lifelic', 'error');
      return;
    }

    try {
      const text = await file.text();
      const obj = JSON.parse(text);
      
      if (!obj.license || !obj.signature) {
        throw new Error('Неверный формат .lifelic');
      }

      const isValid = await verifyLicenseSignature(obj);
      if (!isValid) {
        throw new Error('Подпись не прошла проверку');
      }

      if (!isLicenseValid(obj.license)) {
        throw new Error('Лицензия истекла');
      }

      await chrome.storage.local.set({ 
        license: obj.license, 
        signature: obj.signature 
      });

      const plan = obj.license.plan || 'unknown';
      this.showStatus(`Лицензия установлена ✅ (plan: ${plan})`, 'success');
      
      // Clear file input
      fileInput.value = '';
      
    } catch (error) {
      this.showStatus('Ошибка импорта: ' + error.message, 'error');
    }
  }

  async verifySavedLicense() {
    try {
      const { license, signature } = await chrome.storage.local.get(['license', 'signature']);
      
      if (!license || !signature) {
        this.showStatus('Лицензия не найдена', 'error');
        return;
      }

      const isValid = await verifyLicenseSignature({ license, signature });
      const isValidAndNotExpired = isValid && isLicenseValid(license);
      
      if (isValidAndNotExpired) {
        this.showStatus('Подпись корректна ✅', 'success');
      } else if (isValid) {
        this.showStatus('Подпись корректна, но лицензия истекла ❌', 'error');
      } else {
        this.showStatus('Подпись НЕ прошла ❌', 'error');
      }
    } catch (error) {
      this.showStatus('Ошибка проверки: ' + error.message, 'error');
    }
  }

  async clearSavedLicense() {
    try {
      await chrome.storage.local.remove(['license', 'signature']);
      this.showStatus('Лицензия удалена', 'info');
    } catch (error) {
      this.showStatus('Ошибка удаления лицензии: ' + error.message, 'error');
    }
  }

  async activateLicense() {
    const key = document.getElementById('licenseKey').value.trim();
    const statusEl = document.getElementById('licenseStatus');
    const activateBtn = document.getElementById('activateBtn');

    if (!key) {
      this.showStatus('Please enter a license key', 'error');
      return;
    }

    activateBtn.disabled = true;
    activateBtn.textContent = 'Activating...';

    try {
      const response = await chrome.runtime.sendMessage({
        type: 'LU_ACTIVATE_LICENSE',
        payload: { key }
      });

      if (response.ok) {
        this.showStatus('✅ License activated successfully!', 'success');
        document.getElementById('licenseKey').value = '';
        await this.loadData(); // Reload to update status
      } else {
        this.showStatus(`❌ ${response.message}`, 'error');
      }
    } catch (error) {
      this.showStatus('❌ Error activating license', 'error');
    } finally {
      activateBtn.disabled = false;
      activateBtn.textContent = 'Activate License';
    }
  }

  async exportData() {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'LU_EXPORT_DATA' });
      if (response.ok) {
        const data = response.data;
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `lifeundo-stats-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        this.showStatus('✅ Data exported successfully!', 'success');
      } else {
        this.showStatus('❌ Error exporting data', 'error');
      }
    } catch (error) {
      this.showStatus('❌ Error exporting data', 'error');
    }
  }

  async resetStats() {
    if (!confirm('Are you sure you want to reset all statistics? This action cannot be undone.')) {
      return;
    }

    try {
      // Reset statistics in background
      await chrome.runtime.sendMessage({ type: 'LU_RESET_STATS' });
      await this.loadData(); // Reload to show updated stats
      this.showStatus('✅ Statistics reset successfully!', 'success');
    } catch (error) {
      this.showStatus('❌ Error resetting statistics', 'error');
    }
  }

  showStatus(message, type) {
    const statusEl = document.getElementById('licenseStatus');
    statusEl.textContent = message;
    statusEl.className = `status ${type}`;
    statusEl.classList.remove('hidden');

    // Auto-hide after 5 seconds
    setTimeout(() => {
      statusEl.classList.add('hidden');
    }, 5000);
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new OptionsManager();
});

