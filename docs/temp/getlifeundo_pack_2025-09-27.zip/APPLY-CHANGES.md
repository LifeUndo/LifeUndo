# APPLY-CHANGES.md

## 1. Скопировать файлы на сайт
Положите содержимое `support/`, `en/support/`, `pricing/`, `en/pricing/`, `fund.html`, `en/fund.html`, `success.html`, `en/success.html`, `fail.html`, `en/fail.html`
в соответствующие маршруты проекта (Vercel/Next.js может обслуживать их как статические файлы из `/public`).

Рекомендуемый путь: `/public/...`.

## 2. Футер
Файл `snippets/footer.html` — HTML-вставка. Для Next.js используйте собственный Layout/Component и перенесите содержимое (соцссылки/бейджи/тексты).

## 3. Патч расширения
Примените diff `patches/popup_js_pro_button.diff` к `popup.js` в расширении Firefox 0.3.7.11.
Пересоберите XPI и загрузите в AMO.

## 4. ENV и Redeploy
Внесите переменные в Vercel и выполните деплой без build cache.

## 5. FreeKassa
Проверьте Success/Fail/Result ссылками из проекта. Выполните реальную оплату.

## 6. Smoke
Проверьте чек-лист curl/Invoke-WebRequest из handoff. Дата сборки: 2025-09-27.
