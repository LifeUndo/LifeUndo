# PROJECT_READINESS.md

Запуск LifeUndo/GetLifeUndo: сайт, платежи FreeKassa, расширение Firefox 0.3.7.11, фонд.

## 1) ENV в Vercel
NEXT_PUBLIC_SITE_URL, FK_MERCHANT_ID, FK_SECRET1, FK_SECRET2, ADMIN_TOKEN, EMAIL_RELAY_USER/PASS, SENTRY_DSN, LOGTAIL_TOKEN, DATABASE_URL (app_user). После ввода — Redeploy без build cache.

## 2) FreeKassa
Result: https://www.getlifeundo.com/api/fk/notify
Success: https://www.getlifeundo.com/success
Fail:    https://www.getlifeundo.com/fail
Секреты 1/2 должны совпадать.

## 3) Neon DB
Создать роль app_user (CRUD), включить PITR, обновить DATABASE_URL на app_user.

## 4) Страницы
/support (RU/EN), /pricing (RU/EN), /success, /fail, /fund (RU/EN). Футер с соцсетями + бейджами FreeKassa и «We give 10%».

## 5) Расширение 0.3.7.11
Кнопка Pro → /pricing (RU) /en/pricing (EN). Release notes из handoff. Сборка XPI с POSIX-путями. Загрузка в AMO.

## 6) Smoke tests
/ → 307→www, /ok=200, /admin=401, GET /api/fk/notify=405. /fund, /pricing, /faq, /contacts, /docs → 200.
