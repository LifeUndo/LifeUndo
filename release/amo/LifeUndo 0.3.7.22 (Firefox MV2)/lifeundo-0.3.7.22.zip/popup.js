/* global browser */

async function getLocale(){
  try {
    const { uiLocale } = await browser.storage.local.get('uiLocale');
    if (uiLocale) return uiLocale;
  } catch {}
  const l = (navigator.language||'en').slice(0,2).toLowerCase();
  return ['en','ru','hi','zh','ar','kk','tr'].includes(l) ? l : 'en';
}

function openTab(url){ 
  try {
    browser.tabs.create({ url }); 
  } catch (e) {
    console.error('Failed to open tab:', e);
  }
}

function el(q){ return document.querySelector(q); }
function clear(node){ while(node.firstChild) node.removeChild(node.firstChild); }

function li(text, sub){
  const li = document.createElement('li');
  const t = document.createElement('div');
  t.textContent = text;
  t.className = 'item-title';
  li.appendChild(t);
  if (sub){
    const s = document.createElement('div');
    s.textContent = sub;
    s.className = 'item-sub';
    li.appendChild(s);
  }
  return li;
}

async function readLists(){
  const res = await browser.storage.local.get(['lu_inputs','lu_clipboard']);
  const inputs = res.lu_inputs || [];
  const clip = res.lu_clipboard || [];
  let closed = [];
  try{
    const rc = await browser.sessions.getRecentlyClosed({ maxResults: 20 }) || [];
    closed = rc.filter(x=>x.tab && x.tab.title && x.tab.url)
               .map(x=>({ title: x.tab.title, url: x.tab.url, ts: x.tab.lastAccessed||Date.now() }));
  }catch(e){ closed = []; }
  return { inputs, clip, closed };
}

function renderList(rootSel, items, map){
  const root = el(rootSel);
  if (!root) return;
  clear(root);
  if (!items.length){
    root.appendChild(li('—',''));
    return;
  }
  items.forEach((it)=> root.appendChild(map(it)));
}

async function renderUI(){
  const ff = await isFirefox();
  // заголовок
  const badge = el('#version');
  if (badge) badge.textContent = ff ? 'Free Version (Firefox)' : 'Free Version';

  // показать блоки, убрать «PRO»
  document.querySelectorAll('[data-pro]').forEach(n=> n.removeAttribute('data-pro'));

  const { inputs, clip, closed } = await readLists();
  renderList('#inputs', inputs, it => li(it.text, new Date(it.ts).toLocaleString()));
  renderList('#clipboard', clip, it => li(it.text, new Date(it.ts).toLocaleString()));
  renderList('#tabs', closed, it => li(it.title, it.url));

  // Локализация ссылок
  const locale = await getLocale();
  const L = {
    website:  `https://getlifeundo.com/${locale}`,
    privacy:  `https://getlifeundo.com/${locale}/privacy`,
    support:  `https://getlifeundo.com/${locale}/support`,
    license:  `https://getlifeundo.com/${locale}/license`,
    pricing:  `https://getlifeundo.com/${locale}/pricing`,
  };
  
  // Обновить кнопку Activate VIP
  document.querySelector('#activate')?.addEventListener('click', () => openTab(L.pricing));
  
  // Обновить ссылки в футере
  document.querySelector('a[data-k="website"]')?.setAttribute('href', L.website);
  document.querySelector('a[data-k="privacy"]')?.setAttribute('href', L.privacy);
  document.querySelector('a[data-k="support"]')?.setAttribute('href', L.support);
  document.querySelector('a[data-k="license"]')?.setAttribute('href', L.license);

  // 7-day local reminder
  const s = await browser.storage.local.get(['installTime','upgradeHintDismissed']);
  if (!s.installTime) await browser.storage.local.set({ installTime: Date.now() });
  const show = !s.upgradeHintDismissed && Date.now() - (s.installTime||Date.now()) > 7*24*3600*1000;
  if (show){
    const w = document.createElement('div');
    w.className='note'; 
    w.style.cssText='margin:6px 0;opacity:.9;padding:8px;background:#1e3a8a;border-radius:6px;color:#dbeafe;font-size:13px';
    w.innerHTML='Enjoying LifeUndo? <a href="#" style="color:#60a5fa;text-decoration:none">Upgrade</a> <span id="x" style="float:right;cursor:pointer;font-weight:bold">×</span>';
    w.querySelector('a').onclick = e=>{ e.preventDefault(); openTab(L.pricing); };
    w.querySelector('#x').onclick = async ()=>{ await browser.storage.local.set({ upgradeHintDismissed:true }); w.remove(); };
    document.body.insertBefore(w, document.body.children[1]);
  }
}

async function isFirefox(){
  try {
    const info = await (browser.runtime.getBrowserInfo?.() || Promise.resolve(null));
    return !!info && /firefox|gecko/i.test(`${info.name} ${info.vendor||''}`);
  } catch {
    return /firefox/i.test(navigator.userAgent);
  }
}

document.addEventListener('DOMContentLoaded', renderUI);