— New: DER/raw signature support for VIP licenses
— Improved: error messages for license import/verify
— Fixed: VIP popup behavior (PRO gates removed)
— Security: fully offline verification (ECDSA P-256, SHA-256)



