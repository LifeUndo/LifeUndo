v0.2.2 — improved VIP license validation
• Support for DER and raw (r||s) ECDSA signatures
• Clear error messages for import/verify failures
• Use per-license public JWK or embedded fallback
• Popup properly removes PRO gates when VIP is active



