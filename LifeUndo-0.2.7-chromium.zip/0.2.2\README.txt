LifeUndo 0.2.2 — Release Artifacts

Firefox:
1) Open Firefox → Menu → Add-ons and themes → ⚙ → Install Add-on From File…
2) Select LifeUndo-0.2.2-firefox.xpi

Chromium:
1) Unpack LifeUndo-0.2.2-chromium.zip if needed for local testing or upload to the store.

VIP license:
1) about:addons → LifeUndo → Options → License → Import
2) Select your .lifelic (JSON). Click "Verify" — should show "Signature valid".
3) Open popup on any regular website — VIP badge visible, PRO gates removed.

Checksums:
— See checksums.txt (SHA256)



