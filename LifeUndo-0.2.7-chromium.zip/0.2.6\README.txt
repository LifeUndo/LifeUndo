LifeUndo v0.2.6 — VIP from popup + fixes

Files:
- LifeUndo-0.2.6-firefox.xpi (Firefox extension)
- LifeUndo-0.2.6-chromium.zip (Chrome/Chromium extension)

Key Features:
• VIP license import directly from popup
• Working RU/EN language toggles
• Proper modal closing (ESC/click outside)
• Clear CTAs: Activate VIP & Upgrade to Pro
• Trial hidden when VIP active
• Stable build with POSIX paths

Installation:
1. Firefox: Load temporary add-on via about:debugging
2. Chrome: Load unpacked extension from zip contents

VIP Activation:
1. Open popup → Click "Activate VIP"
2. Select .lifelic file (JSON or armored format)
3. See "VIP activated ✅" message
4. PRO restrictions disappear, VIP badge shows

Release Date: September 14, 2025

