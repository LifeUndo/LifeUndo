/* LifeUndo — popup.js (0.3.7.9.1 UI polish) */

const B = (typeof browser !== 'undefined') ? browser : chrome;
const $ = (q)=>document.querySelector(q);

/* ==== Версия из manifest ==== */
try {
  const v = (B.runtime.getManifest && B.runtime.getManifest().version) || '';
  const badge = document.querySelector('.v'); if (badge) badge.textContent = v ? ('v' + v) : '';
} catch {}

/* ==== Узлы ==== */
const listText = $('#list-text'), emptyText = $('#empty-text'), clearTextBtn = $('#clear-text');
const listTabs = $('#list-tabs'), emptyTabs = $('#empty-tabs');
const listClip = $('#list-clip'), emptyClip = $('#empty-clip'), clearClipBtn = $('#clear-clip');

const statusChip = $('#status-chip');
const btnPro = $('#btn-pro'), btnVip = $('#btn-vip'), linkLicense = $('#open-license');

const btnEN = $('#btn-en'), btnRU = $('#btn-ru');
const wnBtn = $('#whatsnew'), wnClose = $('#wn-close'), wnOverlay = $('#wn-overlay');

/* ==== I18N ==== */
let lang = 'ru';
const i18n = {
  en:{ text:"Latest text inputs", textEmptyTitle:"Nothing yet",
       textEmptySub:"Type text on any regular page and refresh — entries will appear here.",
       tabs:"Recently closed tabs", tabsEmptyTitle:"Nothing yet",
       tabsEmptySub:"Close a couple of tabs on a normal site — they will appear here.",
       clip:"Clipboard history", clipEmptyTitle:"Nothing yet",
       clipEmptySub:"Copy 2–3 fragments (Ctrl/Cmd+C) — items will appear here.",
       clearText:"Clear Text", clearClip:"Clear Clipboard",
       statusFree:"Free · Trial: {d}d {h}h", copy:"Copy", restore:"Restore",
       more:"Show more", less:"Show less", vipActive:"VIP active" },
  ru:{ text:"Недавние вводы текста", textEmptyTitle:"Пока пусто",
       textEmptySub:"Наберите текст на обычной странице и обновите — записи появятся здесь.",
       tabs:"Недавно закрытые вкладки", tabsEmptyTitle:"Пока пусто",
       tabsEmptySub:"Закройте пару вкладок на обычном сайте — они появятся здесь.",
       clip:"История буфера", clipEmptyTitle:"Пока пусто",
       clipEmptySub:"Скопируйте 2–3 фрагмента (Ctrl/Cmd+C) — элементы появятся здесь.",
       clearText:"Очистить текст", clearClip:"Очистить буфер",
       statusFree:"Бесплатная · Триал: {d}д {h}ч", copy:"Скопировать", restore:"Восстановить",
       more:"Показать ещё", less:"Свернуть", vipActive:"VIP активен" }
};
function t(k){ return (i18n[lang]||{})[k] || k; }

function applyI18n(){
  const s1=$('[data-i18n-text]'); if(s1) s1.setAttribute('data-title', t('text'));
  const s2=$('[data-i18n-tabs]'); if(s2) s2.setAttribute('data-title', t('tabs'));
  const s3=$('[data-i18n-clip]'); if(s3) s3.setAttribute('data-title', t('clip'));

  const et=$('#empty-text .ttl'); if(et) et.textContent=t('textEmptyTitle');
  const es=$('#empty-text .sub'); if(es) es.textContent=t('textEmptySub');

  const tt=$('#empty-tabs .ttl'); if(tt) tt.textContent=t('tabsEmptyTitle');
  const ts=$('#empty-tabs .sub'); if(ts) ts.textContent=t('tabsEmptySub');

  const ct=$('#empty-clip .ttl'); if(ct) ct.textContent=t('clipEmptyTitle');
  const cs=$('#empty-clip .sub'); if(cs) cs.textContent=t('clipEmptySub');

  if (clearTextBtn) clearTextBtn.textContent=t('clearText');
  if (clearClipBtn) clearClipBtn.textContent=t('clearClip');
}
applyI18n();

btnEN?.addEventListener('click', ()=>{ lang='en'; applyI18n(); refresh(); });
btnRU?.addEventListener('click', ()=>{ lang='ru'; applyI18n(); refresh(); });

/* ==== Утилиты ==== */
function fmtTime(ts){ try { return new Date(ts).toLocaleTimeString(); } catch{ return ''; } }
function strip(s){ return String(s||'').replace(/\s+/g,' ').trim(); }
function trialLabel(ms){ const d=Math.floor(ms/86400000), h=Math.floor((ms%86400000)/3600000); return t('statusFree').replace('{d}',d).replace('{h}',h); }
function setVisibility(count, listEl, emptyEl, clearBtn){
  if (count>0){ listEl.hidden=false; emptyEl.style.display='none'; if(clearBtn) clearBtn.disabled=false; }
  else { listEl.hidden=true; emptyEl.style.display='block'; if(clearBtn) clearBtn.disabled=true; }
}

/* ==== 'Показать ещё' под текстом + автодетект переполнения ==== */
function addMoreToggle(li){
  const btn=document.createElement('button');
  btn.className='more';
  btn.textContent=t('more');
  btn.onclick=()=>{ const on=li.classList.toggle('expanded'); btn.textContent=on?t('less'):t('more'); };
  return btn;
}

/* ==== Рендер ==== */
function renderList(container, items, type){
  container.innerHTML='';
  for (const it of items){
    const li=document.createElement('li'); li.className='item';

    const meta=document.createElement('div'); meta.className='meta'; meta.textContent = fmtTime(it.ts||Date.now());
    const txt=document.createElement('div');  txt.className='txt';  txt.textContent = strip(it.title||it.val||it.url||'');
    const act=document.createElement('div');  act.className='act';

    if (type==='text' || type==='clip'){
      const b=document.createElement('button'); b.className='copy'; b.textContent=t('copy');
      b.onclick=async()=>{ try{ await navigator.clipboard.writeText(it.val||''); }catch{} };
      act.appendChild(b);
    } else if (type==='tabs'){
      const b=document.createElement('button'); b.className='restore'; b.textContent=t('restore');
      b.onclick=async()=>{ if (it.sessionId){ await B.runtime.sendMessage({type:'restore-session', sessionId: it.sessionId}); await refresh(); } };
      act.appendChild(b);
    }

    // Вставляем минимальную структуру, затем — проверяем реальное переполнение
    li.append(meta, txt, act);
    container.appendChild(li);

    // Если текст реально переполнен — показываем "Показать ещё" под текстом
    queueMicrotask(()=>{
      if (txt.scrollHeight > txt.clientHeight){
        const mw=document.createElement('div'); mw.className='more-wrap';
        mw.appendChild(addMoreToggle(li));
        li.insertBefore(mw, act); // под текстом, над кнопками действий
      }
    });
  }
}

/* ==== Действия ==== */
clearTextBtn?.addEventListener('click', async ()=>{ await B.runtime.sendMessage({type:'clear', target:'text'}); await refresh(); });
clearClipBtn?.addEventListener('click', async ()=>{ await B.runtime.sendMessage({type:'clear', target:'clip'}); await refresh(); });

btnPro?.addEventListener('click', ()=> window.open('https://lifeundo.ru/pricing/index.html','_blank'));
btnVip?.addEventListener('click', ()=> window.location.href='license.html');
linkLicense?.addEventListener('click', (e)=>{ e.preventDefault(); window.location.href='license.html'; });

/* What's new modal */
const openWN = ()=>{ if (wnOverlay) wnOverlay.style.display='flex'; };
const closeWN= ()=>{ if (wnOverlay) wnOverlay.style.display='none'; };
wnBtn?.addEventListener('click', openWN);
wnClose?.addEventListener('click', closeWN);
wnOverlay?.addEventListener('click', (e)=>{ if (e.target===wnOverlay) closeWN(); });
document.addEventListener('keydown', (e)=>{ if (e.key==='Escape') closeWN(); });

/* ==== Данные из background ==== */
async function refresh(){
  const st = await B.runtime.sendMessage({ type:'pull-state' });

  // статус
  if (st.vip) statusChip.textContent = t('vipActive');
  else if (st.pro) statusChip.textContent = 'PRO';
  else statusChip.textContent = trialLabel(st.trialLeftMs||0);

  // текст
  const texts=(st.text||[]).slice(0,20);
  renderList(listText, texts, 'text');
  setVisibility(texts.length, listText, emptyText, clearTextBtn);

  // вкладки
  const tabs=[];
  for (const e of (st.recent||[])){
    if (e.tab?.title && e.tab?.sessionId)
      tabs.push({ title:e.tab.title, url:e.tab.url, ts:e.tab.lastAccessed||Date.now(), sessionId:e.tab.sessionId });
    else if (e.window?.sessionId)
      tabs.push({ title:'[Window]', url:'', ts:Date.now(), sessionId:e.window.sessionId });
  }
  const tabs20=tabs.slice(0,20);
  renderList(listTabs, tabs20, 'tabs');
  setVisibility(tabs20.length, listTabs, emptyTabs);

  // буфер
  const clips=(st.clip||[]).slice(0,20);
  renderList(listClip, clips, 'clip');
  setVisibility(clips.length, listClip, emptyClip, clearClipBtn);
}

refresh();
setInterval(async ()=>{
  try{
    const st = await B.runtime.sendMessage({ type:'pull-state' });
    if (!st.vip && !st.pro && statusChip) statusChip.textContent = trialLabel(st.trialLeftMs||0);
  }catch{}
}, 60000);
