# LifeUndo for Firefox (MV2)

## Install (Firefox)

1. Open about:debugging#/runtime/this-firefox
2. Click "Load Temporary Add-on..."
3. Select `manifest.json` in this folder

This loads the add-on temporarily. For publishing to AMO, you'll need to sign the ZIP.

## Notes

- Uses MV2 APIs compatible with Firefox
- Same feature set as Chrome build
